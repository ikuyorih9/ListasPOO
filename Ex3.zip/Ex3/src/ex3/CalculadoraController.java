package ex3;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TextField;

public class CalculadoraController implements Initializable {
    
    private Double num1 = new Double(0);
    private Double num2 = new Double(0);
    
    @FXML
    private TextField tfInput;
    
    @FXML
    private void clickedAdd(ActionEvent event) {
        num1 = Double.valueOf(tfInput.getText());
    }
    
    @FXML
    private void clickedSub(ActionEvent event) {
        System.out.println("You clicked me!");
    }
    
    @FXML
    private void clickedMul(ActionEvent event) {
        System.out.println("You clicked me!");
    }
    
    @FXML
    private void clickedDiv(ActionEvent event) {
        System.out.println("You clicked me!");
    }
    
    @FXML
    private void clickedEqual(ActionEvent event) {
        System.out.println("You clicked me!");
    }
    
    @FXML
    private void clickedClear(ActionEvent event) {
        tfInput.setText("0");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tfInput.textProperty().addListener(
            new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue,
                String newValue) {
                if (!newValue.matches("\\d*")) {
                    tfInput.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
            }
        );
    }    
    
}
