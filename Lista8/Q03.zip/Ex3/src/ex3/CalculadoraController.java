package ex3;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.TextField;

public class CalculadoraController implements Initializable {
    
    private Integer num1 = new Integer(0);
    private Integer num2 = new Integer(0);
    private int op = 0;
    
    @FXML
    private TextField tfInput;
    
    @FXML
    private void cleanTextField(ActionEvent event) {
        tfInput.setText("");
    }
    
    @FXML
    private void clickedAdd(ActionEvent event) {
        num1 = Integer.valueOf(tfInput.getText());
        tfInput.setText("");
        op = 1;
    }
    
    @FXML
    private void clickedSub(ActionEvent event) {
        num1 = Integer.valueOf(tfInput.getText());
        tfInput.setText("");
        op = 2;
    }
    
    @FXML
    private void clickedMul(ActionEvent event) {
        num1 = Integer.valueOf(tfInput.getText());
        tfInput.setText("");
        op = 3;
    }
    
    @FXML
    private void clickedDiv(ActionEvent event) {
        num1 = Integer.valueOf(tfInput.getText());
        tfInput.setText("");
        op = 4;
    }
    
    @FXML
    private void clickedEqual(ActionEvent event) {
        num2 = Integer.valueOf(tfInput.getText());
        tfInput.setText("");
        
        switch(op){
            
            case 1:
                num1 += num2;
                break;
            
            case 2:
                num1 -= num2;
                break;
                
            case 3:
                num1 *= num2;
                break;
                
            case 4:
                num1 /= num2;
                break;
                  
        }
        
        tfInput.setText(num1.toString());
        System.out.print(num1.intValue());
        
    }
    
    @FXML
    private void clickedClear(ActionEvent event) {
        tfInput.setText("0");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tfInput.textProperty().addListener(
            new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue,
                String newValue) {
                if (!newValue.matches("\\d*")) {
                    tfInput.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
            }
        );
    }    
    
}
