package ex1;

public class Par<T extends Comparable> {
    
    Par(T _primeiro, T _segundo){
        primeiro = _primeiro;
        segundo = _segundo;
    }
    
    private T primeiro;
    private T segundo;
    
    public T getMax(){
        if(0 >= primeiro.compareTo(segundo))
            return primeiro;
        else
            return segundo;
    }
    
    public T getMin(){
        if(0 <= primeiro.compareTo(segundo))
            return segundo;
        else
            return primeiro;
    }
    
    @Override
    public String toString(){
        return (primeiro.toString()+ segundo.toString());
    }
}
